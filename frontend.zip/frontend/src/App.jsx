import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./Pages/Home";
import About from "./Pages/About";
import Evaluation from "./Pages/Evaluation";
import Detection from "./Pages/Detection";

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/evaluation" element={<Evaluation />} />
        <Route path="/detection" element={<Detection />} />
      </Routes>
    </>
  );
}

